# PolyMarketCap Overview

Starter template for multi-chain market metrics. Replace mock adapter with real providers.
