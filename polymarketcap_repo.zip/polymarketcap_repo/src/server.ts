import http from 'http';
import { fetchMockPrices } from './adapters/mock.js';

const server = http.createServer(async (req, res) => {
  if (!req.url) return;
  if (req.url.startsWith('/prices')) {
    const symbols = new URL(req.url, 'http://localhost').searchParams.get('symbols')?.split(',') || ['BTC','ETH','SOL'];
    const data = await fetchMockPrices(symbols);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ data }));
    return;
  }
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('PolyMarketCap API. Try /prices?symbols=BTC,ETH,SOL');
});

const PORT = process.env.PORT ? Number(process.env.PORT) : 8787;
server.listen(PORT, () => console.log(`PolyMarketCap server running on :${PORT}`));
