import { fetchMockPrices } from './adapters/mock.js';

async function main() {
  const symbols = process.argv.slice(2);
  const list = symbols.length ? symbols : ['BTC', 'ETH', 'SOL', 'POLY'];
  const data = await fetchMockPrices(list);
  console.log('PolyMarketCap — demo output:\n');
  for (const p of data) {
    console.log(`${p.symbol}: $${p.priceUsd} | MC: $${p.marketCapUsd} | 24h: $${p.volume24hUsd} (src: ${p.source})`);
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
