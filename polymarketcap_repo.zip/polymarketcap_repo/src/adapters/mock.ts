import { PricePoint } from '../core/types.js';

export async function fetchMockPrices(symbols: string[]): Promise<PricePoint[]> {
  const now = Date.now();
  return symbols.map((s, i) => ({
    symbol: s.toUpperCase(),
    priceUsd: Number((1 + (i % 5) * 0.1234).toFixed(4)),
    marketCapUsd: Number((1e9 + i * 1e7).toFixed(0)),
    volume24hUsd: Number((5e6 + i * 1e5).toFixed(0)),
    source: 'mock',
    ts: now
  }));
}
