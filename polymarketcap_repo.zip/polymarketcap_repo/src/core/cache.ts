export class TTLCache<T> {
  private data = new Map<string, { value: T; exp: number }>();
  constructor(private ttlMs: number) {}
  get(key: string): T | undefined {
    const hit = this.data.get(key);
    if (!hit) return undefined;
    if (Date.now() > hit.exp) {
      this.data.delete(key);
      return undefined;
    }
    return hit.value;
  }
  set(key: string, value: T) {
    this.data.set(key, { value, exp: Date.now() + this.ttlMs });
  }
}
