export type Chain = 'ethereum' | 'polygon' | 'base' | 'arbitrum' | string;

export interface PricePoint {
  symbol: string;
  priceUsd: number;
  marketCapUsd?: number;
  volume24hUsd?: number;
  source: string;
  ts: number;
}

export interface Config {
  chains: Chain[];
  providers: Record<string, any>;
  cacheTtlSeconds: number;
}
