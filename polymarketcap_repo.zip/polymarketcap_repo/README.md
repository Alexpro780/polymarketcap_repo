# PolyMarketCap

**PolyMarketCap** is a lightweight, multi-chain market data template for building your own crypto market cap dashboard and APIs.
It ships with a TypeScript starter, mock data adapter, and minimal HTTP server — so you can plug real providers later.

## Features
- Modular data-source adapters (RPC/Subgraph/DEX/CEX)
- Unified typings for price, market cap, volume, TVL
- Simple TTL cache layer
- CLI demo and minimal HTTP server
- GitHub Actions CI

## Quick Start
```bash
git clone https://github.com/yourusername/polymarketcap.git
cd polymarketcap
npm install
cp config.example.json config.json
npm run build
npm start            # demo CLI
npm run server       # HTTP API
```

## Structure
- `src/adapters/` – data providers (mock included)
- `src/core/` – types, cache, aggregation logic
- `src/server.ts` – minimal HTTP server
- `src/cli.ts` – CLI to print aggregated stats
- `.github/workflows/ci.yml` – CI pipeline
- `docs/` – docs and notes
- `LICENSE` – MIT

## License
MIT
